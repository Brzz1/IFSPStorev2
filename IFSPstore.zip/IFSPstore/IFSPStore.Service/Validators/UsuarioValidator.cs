﻿using FluentValidation;
using IFSPStore.Domain.Entities;

namespace IFSPStore.Service.Validators
{
    public class UsuarioValidator : AbstractValidator<Usuario>
    {
        public UsuarioValidator() 
        {
            RuleFor(c => c.Nome)
                .NotEmpty().WithMessage("Por favor informe o nome: ")
                .NotNull().WithMessage("Por favor informe o nome: ");

            RuleFor(c => c.Senha)
                .MinimumLength(8).WithMessage("Sua senha precisa ter no minimo 8 caracteres.")
                .MaximumLength(16).WithMessage("Sua senha precisa ter no maximo 8 caracteres.")
                .Matches(@"[A-Z]+").WithMessage("Sua senha precisa conter no minimo uma letra maiuscula")
                .Matches(@"[a-z]+").WithMessage("Sua senha precisa conter no minimo uma letra minuscula")
                .Matches(@"[0-9]+").WithMessage("Sua senha precisa conter no minimo um numero")
                .NotEmpty().WithMessage("Por favor informe a senha: ")
                .NotNull().WithMessage("Por favor informe a senha: ");

            RuleFor(c => c.Email)
                .EmailAddress().WithMessage("Email inválido.")
                .NotEmpty().WithMessage("Por favor informe o email: ")
                .NotNull().WithMessage("Por favor informe o email: ");

            RuleFor(c => c.Login)
                .NotEmpty().WithMessage("Por favor informe o login: ")
                .NotNull().WithMessage("Por favor informe o login: ");



        }
    }
}
