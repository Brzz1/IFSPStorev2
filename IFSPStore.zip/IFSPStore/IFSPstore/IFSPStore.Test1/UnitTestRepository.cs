﻿using IFSPStore.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IFSPStore.Test1
{
    [TestClass]
    public class UnitTestRepository
    {
        public partial class MyDbContext : DbContext
        {
            public DbSet<Usuario> Usuarios { get; set; }
            public DbSet<Cidade> Cidades { get; set; }
            public DbSet<Cliente> Clientes { get; set; }
            public DbSet<Grupo> Grupos { get; set; }
            public DbSet<Produto> Produtos { get; set; }
            public DbSet<Venda> Vendas { get; set; }
            public DbSet<VendaItem> VendaItens { get; set; }

            public MyDbContext()
            {
                Database.EnsureCreated();
            }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                var server = "localhost";
                var port = "3306";
                var database = "IFSPStore";
                var username = "root";
                var password = "ifsp";
                var StrCon = $"Server={server};Port={port};Database={database};" +
                    $"Uid={username};Pwd={password}";
                if (!optionsBuilder.IsConfigured)
                {
                    optionsBuilder.UseMySql(StrCon, ServerVersion.AutoDetect(StrCon));
                }
            }
        }

        [TestMethod]
        public void TestInsertCidades()
        {
            using (var context = new MyDbContext())
            {
                var cidade = new Cidade
                {
                    Nome = "Birigui",
                    Estado = "SP"
                };
                context.Cidades.Add(cidade);

                cidade = new Cidade
                {
                    Nome = "Araçatuba",
                    Estado = "SP"
                };
                context.Cidades.Add(cidade);

                context.SaveChanges();
            }
        }

        [TestMethod]
        public void TestListCidades()
        {
            using (var context = new MyDbContext())
            {
                foreach (var cidade in context.Cidades)
                {
                    Console.WriteLine(JsonSerializer.Serialize(cidade));
                }
            }
        }

        [TestMethod]
        public void TestInsertClientes()
        {
            using (var context = new MyDbContext())
            {
                var cidade = context.Cidades.FirstOrDefault(c => c.Id == 1);
                var cliente = new Cliente
                {
                    Nome = "Roberto Carlos",
                    Endereco = "Rua Carvalho",
                    Documento = "RG",
                    Bairro = "Não sei",
                    Cidade = cidade
                };
                context.Clientes.Add(cliente);

                cliente = new Cliente
                {
                    Nome = "Araçatuba",
                    Endereco = "Avenida Jose Lima",
                    Documento = "RG",
                    Bairro = "Centro",
                    Cidade = cidade
                };
                context.Clientes.Add(cliente);

                context.SaveChanges();
            }
        }
        [TestMethod]
        public void TestListClientes()
        {
            using (var context = new MyDbContext())
            {
                foreach (var cliente in context.Clientes)
                {
                    Console.WriteLine(JsonSerializer.Serialize(cliente));
                }
            }
        }

        [TestMethod]
        public void TestInsertGrupo()
        {
            using (var context = new MyDbContext())
            {
                var grupo = new Grupo
                {
                    Nome = "Roberto Carlos"
                };
                context.Grupos.Add(grupo);

                grupo = new Grupo
                {
                    Nome = "Araçatuba"
                };
                context.Grupos.Add(grupo);
                context.SaveChanges();
            }
        }
        public void TestListGrupo()
        {
            using (var context = new MyDbContext())
            {
                foreach (var grupo in context.Grupos)
                {
                    Console.WriteLine(JsonSerializer.Serialize(grupo));
                }
            }
        }
        [TestMethod]
        public void TestInsertProduto()
        {
            using (var context = new MyDbContext())
            {
                var grupo = context.Grupos.FirstOrDefault(c => c.Id == 1);
                var produto = new Produto
                {
                    Nome = "Arroz",
                    Preco = (decimal?)13.80f,
                    Quantidade = 1,
                    DataCompra = DateTime.Now,
                    UnidadeVenda = "ab",
                    Grupo = grupo 
                    
                };
                context.Produtos.Add(produto);

                produto = new Produto
                {
                    Nome = "Pão",
                    Preco = (decimal?)5.80f,
                    Quantidade = 1,
                    DataCompra = DateTime.Now,
                    UnidadeVenda = "ba",
                    Grupo = grupo
                };
                context.Produtos.Add(produto);
                context.SaveChanges();
            }

        }
        [TestMethod]
        public void TestListProduto()
        {
            using (var context = new MyDbContext())
            {
                foreach (var produto in context.Produtos)
                {
                    Console.WriteLine(JsonSerializer.Serialize(produto));
                }
            }
        }
        [TestMethod]
        public void TestInsertUsuario()
        {
            using (var context = new MyDbContext())
            {
                var usuario = new Usuario
                {
                    Nome = "Arroz",
                    Senha = "123",
                    Login = "farofa123",
                    Email = "farofa123@gmail.com",
                    DataCadastro = DateTime.Now,
                    DataLogin = DateTime.Now,
                    Ativo = true,

            };
                context.Usuarios.Add(usuario);

                usuario = new Usuario
                {
                    Nome = "Pão",
                    Senha = "345",
                    Login = "farofa345",
                    Email = "farofa345@gmail.com",
                    DataCadastro = DateTime.Now,
                    DataLogin = DateTime.Now,
                    Ativo = true,
                };
                context.Usuarios.Add(usuario);
                context.SaveChanges();
            }

        }

    }
}